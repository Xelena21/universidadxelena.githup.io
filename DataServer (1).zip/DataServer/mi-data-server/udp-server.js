const dgram = require('dgram');
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'Matt',
    password: '14241543',
    database: 'gps_data'
});

const server = dgram.createSocket('udp4');

server.on('listening', () => {
    const address = server.address();
    console.log(`Servidor UDP escuchando en el puerto ${address.port}`);
});

server.on('message', (message) => {
    try {
        const data = message.toString();
        console.log(`Datos recibidos: ${data}`);
        
        const parts = data.split(', ');
        const latitudPart = parts.find(part => part.startsWith('Latitud:'));
        const longitudPart = parts.find(part => part.startsWith('Longitud:'));

        if (latitudPart && longitudPart) {
            const latitud = latitudPart.split(':')[1].trim();
            const longitud = longitudPart.split(':')[1].trim();

            const fechaHora = new Date().toISOString().slice(0, 19).replace('T', ' ');

            const query = 'INSERT INTO ubicaciones (latitud, longitud, fechaHora) VALUES (?, ?, ?)';
            connection.query(query, [latitud, longitud, fechaHora], (error, results) => {
                if (error) {
                    console.error('Error al almacenar datos en la base de datos:', error);
                } else {
                    console.log('Datos almacenados en la base de datos');
                }
            });
        } else {
            console.error('Datos incompletos recibidos');
        }
    } catch (error) {
        console.error('Error al procesar el mensaje:', error);
    }
});

server.bind(3000);
