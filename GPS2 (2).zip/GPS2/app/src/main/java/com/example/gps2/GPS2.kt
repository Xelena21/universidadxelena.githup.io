package com.example.gps2

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class GPS2 : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gps2)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val textViewLatitude: TextView = findViewById(R.id.textViewLatitude)
        val textViewLongitude: TextView = findViewById(R.id.textViewLongitude)

        getLocationAndUpdateUI(textViewLatitude, textViewLongitude)

        GlobalScope.launch {
            repeat(Int.MAX_VALUE) {
                val ipAddress = findViewById<EditText>(R.id.editTextIPAddress).text.toString()
                val portStr = findViewById<EditText>(R.id.editTextPort).text.toString()
                val port = portStr.toIntOrNull()

                if (ipAddress.isNotEmpty() && port != null) {
                    getLocationAndSendData(ipAddress, port)
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@GPS2, "Ingrese la dirección IP y el puerto", Toast.LENGTH_SHORT).show()
                    }
                }

                delay(5000) // Pausa de 5 segundos
            }
        }
    }

    private fun getLocationAndUpdateUI(textViewLatitude: TextView, textViewLongitude: TextView) {
        GlobalScope.launch(Dispatchers.Main) {
            try {
                val location = getLastLocation()

                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude

                    textViewLatitude.text = "Latitud: $latitude"
                    textViewLongitude.text = "Longitud: $longitude"
                } else {
                    Toast.makeText(this@GPS2, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
                }
            } catch (ex: Exception) {
                Toast.makeText(this@GPS2, "Error al obtener la ubicación: ${ex.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun getLastLocation(): Location? {
        return suspendCoroutine { continuation ->
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location: Location? ->
                        continuation.resume(location)
                    }
                    .addOnFailureListener { exception: Exception ->
                        continuation.resumeWithException(exception)
                    }
            } else {
                continuation.resume(null)
            }
        }
    }

    private suspend fun getLocationAndSendData(ipAddress: String, port: Int) {
        val location = getLastLocation()

        if (location != null) {
            val latitude = location.latitude
            val longitude = location.longitude
            val locationData = "Latitud: $latitude, Longitud: $longitude"

            withContext(Dispatchers.IO) {
                try {
                    val sendData = locationData.toByteArray()
                    val inetAddress = InetAddress.getByName(ipAddress)
                    val datagramPacket = DatagramPacket(sendData, sendData.size, inetAddress, port)

                    val socket = DatagramSocket()
                    socket.send(datagramPacket)
                    socket.close()

                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@GPS2, "Datos enviados por UDP", Toast.LENGTH_SHORT).show()
                    }
                } catch (ex: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@GPS2,
                            "Error al enviar los datos por UDP: ${ex.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                        ex.printStackTrace()
                    }
                }
            }
        } else {
            withContext(Dispatchers.Main) {
                Toast.makeText(this@GPS2, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
            }
        }
    }
}